﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AutoMuhely
{
    public partial class módosítMunkafolyamat : Form
    {
        public módosítMunkafolyamat()
        {
            InitializeComponent();
        }

        public event EventHandler módosítMunkafolyamatMódosítva;


        private void módosítMunkafolyamat_Load(object sender, EventArgs e)
        {

        }
    }
}
